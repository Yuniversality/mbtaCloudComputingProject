const fs = require('fs');
const html = fs.readFileSync('index.html', { encoding:'utf8' });
var AWS = require("aws-sdk"),
 docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    let modifiedHTML = dynamicForm(html,event.queryStringParameters);
    
    const response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'text/html',
        },
        body: modifiedHTML,
    };
    return response;
};

function dynamicForm(html,queryStringParameters){
    var formres = "";
    if(queryStringParameters){
        let tripName = "";
        Object.values(queryStringParameters).forEach(val => {
                tripName = tripName + val;
        });
        formres = formres + tripName + " ";
            
        const params = {
            TableName: "MBTA_Stops", 
            Key: {
                id: tripName
            }
        }
        
        formres = formres + " Trip Time: ";
        
        try {
            const data = await docClient.get(params).promise()
            /*formres = formres + JSON.stringify(data);*/
        }
        catch (err) {
            return { error: err }
        }
        
    }
    return html.replace('{formResults}','<h4>Form Submission: '+formres+'</h4>')
}
