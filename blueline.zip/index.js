const fs = require('fs');
const html = fs.readFileSync('index.html', { encoding:'utf8' });

exports.handler = async (event) => {
    let modifiedHTML = dynamicForm(html,event.queryStringParameters);
    
    const response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'text/html',
        },
        body: modifiedHTML,
    };
    return response;
};

function dynamicForm(html,queryStringParameters){
    let formres = '';
    let startingStation = -1;
    let endingStation = -2;
    const minute = 60000;
    if(queryStringParameters){
            Object.values(queryStringParameters).forEach(val => {
                    switch (val){
                        case "bowdoin":
                            if (startingStation == -1)
                            {
                                startingStation = 0;
                            }
                            else if (endingStation == -2)
                            {
                                endingStation = 0;
                            }
                            break;
                         case "government center":
                            if (startingStation == -1)
                            {
                                startingStation = 1;
                            }
                            else if (endingStation == -2)
                            {
                                endingStation = 1;
                            }
                            break;
                         case "state":
                            if (startingStation == -1)
                            {
                                startingStation = 2;
                            }
                            else if (endingStation == -2)
                            {
                                endingStation = 2;
                            }
                            break;
                        case "aquarium":
                            if (startingStation == -1)
                            {
                                startingStation = 3;
                            }
                            else if (endingStation == -2)
                            {
                                endingStation = 3;
                            }
                            break;
                        case "maverick":
                            if (startingStation == -1)
                            {
                                startingStation = 4;
                            }
                            else if (endingStation == -2)
                            {
                                endingStation = 4;
                            }
                            break;
                        case "airport":
                            if (startingStation == -1)
                            {
                                startingStation = 5;
                            }
                            else if (endingStation == -2)
                            {
                                endingStation = 5;
                            }
                            break;
                        case "wood island":
                            if (startingStation == -1)
                            {
                                startingStation = 6;
                            }
                            else if (endingStation == -2)
                            {
                                endingStation = 6;
                            }
                            break;
                        case "orient heights":
                            if (startingStation == -1)
                            {
                                startingStation = 7;
                            }
                            else if (endingStation == -2)
                            {
                                endingStation = 7;
                            }
                            break;
                        case "suffolk downs":
                            if (startingStation == -1)
                            {
                                startingStation = 8;
                            }
                            else if (endingStation == -2)
                            {
                                endingStation = 8;
                            }
                            break;
                        case "beachmont":
                            if (startingStation == -1)
                            {
                                startingStation = 9;
                            }
                            else if (endingStation == -2)
                            {
                                endingStation = 9;
                            }
                            break;
                        case "revere beach":
                            if (startingStation == -1)
                            {
                                startingStation = 10;
                            }
                            else if (endingStation == -2)
                            {
                                endingStation = 10;
                            }
                            break;
                        case "wonderland":
                            if (startingStation == -1)
                            {
                                startingStation = 11;
                            }
                            else if (endingStation == -2)
                            {
                                endingStation = 11;
                            }
                            break;
                    }
                    // (val == "wonderland")
                    // {
                    //     formres = formres + "1" + "";
                    // }
                    formres =formres+val+' ';
                
                  
            });
            let stationsApart = Math.abs(startingStation - endingStation);
            let travelTime = 0;
            if (stationsApart == 0)
            {
                travelTime = 0;    
            }
            else 
            {
                travelTime = (stationsApart * minute) + Math.floor(Math.random() * 10000) + Math.floor(Math.random() * 1000) + Math.floor(Math.random() * 100);
            }
            formres = formres + "Travel Time: " + travelTime + "ms";
    }
    return html.replace('{formResults}','<h4>Form Submission: '+formres+'</h4>')
}